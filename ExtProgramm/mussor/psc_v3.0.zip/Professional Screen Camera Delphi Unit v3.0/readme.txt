Professional Screen Camera Delphi Unit v3.0 Freeware (Delphi 7 To Up)
Developed 2008 by Mohammad Reza Hanifeh Pour (MRH Software Co.) 
E-Mail: mrh.info2007@gmail.com
Web Site: http://www.mrhsoftware.somme.com
Author Straight Tel: +98-2177644130
Address: 29 Rezai St. Namjo Av. F2 Tehran-Iran.
------------------------------------------------------------------
Comments author:

I developed this professional screen camera component with delphi (captures the activity on a screen or delphi form and writes it into an AVI file. it supports all compressors, the program contains code derived from MRH Software Co. OPENSOURCE). 

I'm using a TThread for the recording function and a "transparent" window for a draw frame. This window is always on top of all windows and only has a frame as window region (Frame is set up by Region). In the recording function I call a paint method of the draw window for every frame (PaintBorder).
also i add at this unit capability record audio of input device.
Notice: for run this app you need to "wave audio package" a free component by Kambiz R. Khojasteh, for download update packages go to: http://www.delphiarea.com

If there's anybody who would like to share some time in improving something or just try it out, please send me an email!
------------------------------------------------------------------
Warranty info:

This code and information is provided "as is" without warranty of
any kind, either expressed or implied, including but not limited
to the implied warranties of merchantability and/or fitness for a
particular purpose.

You may use and modify this code for your personal use only.
You may also redistribute this code providing that
a) No fee is charged and b) This copyright notice
is retained in the source code.

You may not use this code for commercial purposes
without the express permission of the copyright holder

Copyright (c) 2007 MRH Software Co.
------------------------------------------------------------------
Licence info:

Please also notice the License agreeements from MRH Software Co. OPENSOURCE:
This product is FREEWARE and you are free to duplicate and distribute this software through the internet or any preferred media.
If you create an product that contains code derived from MRH Software Co., you are free to distribute it for any purposes, including commercial purposes. However, your product must include an acknowledgement that mention it contains code from MRH Software Co. A simple statement like "Professional Screen Camera By MRH Software Co."
in the AboutBox will do. You are not obliged to reveal the source code of your derived product but are encouraged to do so.
-------------------------------------------------------------------
Keep on hacking!
thanks:
     Kambiz R. Khojasteh  -----  http://www.delphiarea.com
