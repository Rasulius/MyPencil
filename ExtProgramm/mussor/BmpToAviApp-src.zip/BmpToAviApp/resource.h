//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BmpToAvi.rc
//
#define IDR_MAINFRAME                   101
#define IDD_ABOUTBOX                    102
#define IDD_BMPTOAVI_DIALOG             103
#define IDD_PROGRESS                    104
#define IDS_ABOUTBOX                    200
#define IDS_APP_LICENSE                 201
#define IDS_AVI_FILTER                  202
#define IDS_HLINK_CANT_LAUNCH           203
#define IDS_MD_BAD_BITMAP_PROPS         204
#define IDS_MD_BAD_FILENAME_FORMAT      205
#define IDS_MD_BITMAP_READ_ERROR        206
#define IDS_MD_BITMAP_SEQ_NOT_FOUND     207
#define IDS_MD_CANCEL_CHECK             208
#define IDS_MD_MISSING_FRAME            209
#define IDS_MD_NO_SRC_FOLDER            210
#define IDS_MD_SRC_FOLDER_NOT_FOUND     211
#define IDS_MD_SUCCESS                  212
#define IDC_ABOUT_LICENSE               1001
#define IDC_ABOUT_TEXT                  1002
#define IDC_ABOUT_URL                   1003
#define IDC_MD_FRAME_RATE               1004
#define IDC_MD_SRC_BROWSE_BTN           1005
#define IDC_MD_SRC_FOLDER_EDIT          1006
#define IDC_PROGRESS                    1007

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                1
#define _APS_NEXT_RESOURCE_VALUE        213
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
