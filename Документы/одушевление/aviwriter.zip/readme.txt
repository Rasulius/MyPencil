TAviWriter by Elliott Shevin (shevine@aol.com).

This component will write an AVI file containing
a single video stream of any number of TBitmaps,
plus a single audio stream with one WAV file.

Install as you usually do.

Thanks are due to Anders Melander, whose sample
code for building an AVI from an animated GIF
was substantially lifted for this component.